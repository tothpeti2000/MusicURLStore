/**
 * Delete the track with the given trackID from the playlist stored in res.locals.playlist
 * Redirect to /playlist/:playlistID after success
 */

module.exports = (objRepo) => {
  return (req, res, next) => {
    return next();
  };
};
