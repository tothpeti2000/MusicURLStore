/**
 * Add a new track to the playlist stored in res.locals.playlist from req.body
 * Redirect to /playlist/:playlistID after success
 */

module.exports = (objRepo) => {
  return (req, res, next) => {
    return next();
  };
};
